# Study Tracker Pro

A mobile-friendly, installable study tracker for Physics, Chemistry and Mathematics.

## Features
- Unlimited chapters and bullet points
- Automatic saving on the current device/browser
- Tick/untick completed points
- Search
- Overall progress
- Edit/delete chapters and bullet points
- JSON backup and restore
- Installable as a phone-style app
- Offline cache after first successful load

## Important about data
This version stores study data locally on the device/browser. Hosting the app online does NOT automatically synchronize your data between phones.

For cross-device synchronization, a cloud database + authentication must be connected (for example, Supabase or Firebase). Do not put private credentials into this static package.

## Publish
Upload `index.html`, `manifest.json`, `sw.js`, and `icon.svg` to the root of a GitHub Pages repository and publish the main branch/root.
